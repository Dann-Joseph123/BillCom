package com.secondapplication.app;

import android.content.ContentValues;
import android.content.Context;
import android.content.SearchRecentSuggestionsProvider;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {



    public static final String DBNAME = "Login.db";

    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase MyDataBase) {
        MyDataBase.execSQL("Create table users(name TEXT primary key, username TEXT, password TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDataBase, int i, int i1) {
        MyDataBase.execSQL("Drop Table if exists users");
    }

    public Boolean insertData (String name, String username, String password){
        SQLiteDatabase MyDataBase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDataBase.insert("users",null,contentValues);
        if (result == -1) return false;
        else
            return true;

    }

    public Boolean checkname (String name){//d ko alam para san to
        SQLiteDatabase MyDataBase = this.getWritableDatabase();
        Cursor cursor = MyDataBase.rawQuery("Select * from users where name = ?", new String[] {name});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkNameUsername(String name, String username){// eto yung orig
        SQLiteDatabase MyDataBase = this.getWritableDatabase();
        Cursor cursor = MyDataBase.rawQuery("Select * from users where name = ? and username = ?", new String[] {name, username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;

    }
    public Boolean checkNameUsernamePassword(String name, String username, String password){
        SQLiteDatabase MyDataBase = this.getWritableDatabase();
        Cursor cursor = MyDataBase.rawQuery("Select * from users where name = ? and username = ? and password = ?", new String[] {name, username, password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;

    }
    public Boolean checkUsernamePassword(String username, String password){//eto yung orig
        SQLiteDatabase MyDataBase = this.getWritableDatabase();
        Cursor cursor = MyDataBase.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;

    }

}