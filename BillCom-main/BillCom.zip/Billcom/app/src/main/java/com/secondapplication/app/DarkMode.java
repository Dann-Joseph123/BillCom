package com.secondapplication.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;


public class DarkMode extends AppCompatActivity {

    SwitchCompat aSwitch;
    Button btnBack;
    private static String PREFERENCES = "preferences";
    private static String SWITCH_STATUS = "switch_Status";
    boolean switch_status;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dark_mode);

        aSwitch =  findViewById(R.id.switcher);
        btnBack =  findViewById(R.id.btnBackDarkMode);

        sharedPreferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        editor = getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit();

        switch_status = sharedPreferences.getBoolean(SWITCH_STATUS, false);
        aSwitch.setChecked(switch_status);


        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor.putBoolean(SWITCH_STATUS,true);
                    editor.apply();
                    aSwitch.setChecked(true);

                }
                else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor.putBoolean(SWITCH_STATUS,false);
                    editor.apply();
                    aSwitch.setChecked(false);
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DarkMode.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}